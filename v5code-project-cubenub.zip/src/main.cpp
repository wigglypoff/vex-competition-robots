#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    10, 1           
// clawMotor            motor         3               
// armMotor             motor         8               
// ---- END VEXCODE CONFIGURED DEVICES ----

using namespace vex;
int main() {
// Initializing Robot Configuration. DO NOT REMOVE!
vexcodeInit();
 
//280-210-130
armMotor.setStopping(coast);
   armMotor.setTimeout(3, seconds);
   armMotor.spinToPosition(260, degrees);
   wait(0.5, seconds);
 
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(-180, degrees);
   wait(0.5, seconds);
 
Drivetrain.driveFor(forward, 260, mm);
wait(0.5, seconds);
 
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(180, degrees);
   wait(0.5,seconds);
 
armMotor.setStopping(coast);
   armMotor.setTimeout(4, seconds);
   armMotor.spinToPosition(360, degrees);
   wait(0.5, seconds);
 
Drivetrain.driveFor(reverse, 300, mm);
wait(0.5, seconds);
 
Drivetrain.turnFor(left, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
Drivetrain.driveFor(forward, 600, mm);
wait(0.5, seconds);
Drivetrain.turnFor(left, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
Drivetrain.driveFor(forward, 300, mm);
wait(0.5, seconds);
 
armMotor.setStopping(coast);
   armMotor.setTimeout(5, seconds);
   armMotor.spinToPosition(250, degrees);
   wait(1, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(-180, degrees);
   wait(1, seconds);
armMotor.setStopping(coast);
   armMotor.setTimeout(4, seconds);
   armMotor.spinToPosition(500, degrees);
   wait(1, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(180, degrees);
   wait(1, seconds);
 

Drivetrain.driveFor(reverse, 300, mm);
wait(0.5, seconds);
Drivetrain.turnFor(left, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
Drivetrain.driveFor(forward, 600, mm);
wait(0.5, seconds);
Drivetrain.turnFor(left, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
 
armMotor.setStopping(coast);
   armMotor.setTimeout(4, seconds);
   armMotor.spinToPosition(210, degrees);
   wait(0.5, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(-180, degrees);
   wait(0.5, seconds);
Drivetrain.driveFor(forward, 300, mm);
wait(1, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(180, degrees);
   wait(0.5,seconds);
armMotor.setStopping(coast);
   armMotor.setTimeout(4, seconds);
   armMotor.spinToPosition(360, degrees);
   wait(0.5, seconds);
Drivetrain.driveFor(reverse, 300, mm);
wait(1, seconds);
 
Drivetrain.turnFor(left, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
Drivetrain.driveFor(forward, 600, mm);
wait(0.5, seconds);
Drivetrain.turnFor(right, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
Drivetrain.driveFor(forward, 300, mm);
wait(0.5, seconds);
 
armMotor.setStopping(coast);
   armMotor.setTimeout(5, seconds);
   armMotor.spinToPosition(250, degrees);
   wait(1, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(-180, degrees);
   wait(1, seconds);
armMotor.setStopping(coast);
   armMotor.setTimeout(4, seconds);
   armMotor.spinToPosition(500, degrees);
   wait(1, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(180, degrees);
   wait(1, seconds);
 

Drivetrain.driveFor(reverse, 300, mm);
wait(0.5, seconds);
Drivetrain.turnFor(right, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
Drivetrain.driveFor(forward, 600, mm);
wait(0.5, seconds);
Drivetrain.turnFor(left, 75, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
armMotor.setStopping(coast);
   armMotor.setTimeout(5, seconds);
   armMotor.spinToPosition(130, degrees);
   wait(0.5, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(-180, degrees);
   wait(0.5, seconds);
Drivetrain.driveFor(forward, 300, mm);
wait(1, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(180, degrees);
   wait(0.5,seconds);
armMotor.setStopping(coast);
   armMotor.setTimeout(4, seconds);
   armMotor.spinToPosition(360, degrees);
   wait(0.5, seconds);
Drivetrain.driveFor(reverse, 300, mm);
wait(1, seconds);
 
Drivetrain.turnFor(right, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
Drivetrain.driveFor(forward, 600, mm);
wait(0.5, seconds);
Drivetrain.turnFor(right, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
Drivetrain.driveFor(forward, 300, mm);
wait(0.5, seconds);
 
armMotor.setStopping(coast);
   armMotor.setTimeout(5, seconds);
   armMotor.spinToPosition(250, degrees);
   wait(1, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(-180, degrees);
   wait(1, seconds);
armMotor.setStopping(coast);
   armMotor.setTimeout(4, seconds);
   armMotor.spinToPosition(500, degrees);
   wait(1, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(180, degrees);
   wait(1, seconds);
 

Drivetrain.driveFor(reverse, 300, mm);
wait(0.5, seconds);
Drivetrain.turnFor(right, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
Drivetrain.driveFor(forward, 600, mm);
wait(0.5, seconds);
Drivetrain.turnFor(right, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
 
armMotor.setStopping(coast);
   armMotor.setTimeout(5, seconds);
   armMotor.spinToPosition(50, degrees);
   wait(0.5, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(-180, degrees);
   wait(0.5, seconds);
Drivetrain.driveFor(forward, 300, mm);
wait(1, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(180, degrees);
   wait(0.5,seconds);
armMotor.setStopping(coast);
   armMotor.setTimeout(4, seconds);
   armMotor.spinToPosition(360, degrees);
   wait(0.5, seconds);
Drivetrain.driveFor(reverse, 300, mm);
wait(1, seconds);
 
 Drivetrain.turnFor(right, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
Drivetrain.driveFor(forward, 600, mm);
wait(0.5, seconds);
Drivetrain.turnFor(left, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
Drivetrain.driveFor(forward, 300, mm);
wait(0.5, seconds);
 
armMotor.setStopping(coast);
   armMotor.setTimeout(5, seconds);
   armMotor.spinToPosition(250, degrees);
   wait(0.5, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(-180, degrees);
   wait(0.5, seconds);
armMotor.setStopping(coast);
   armMotor.setTimeout(5, seconds);
   armMotor.spinToPosition(500, degrees);
   wait(0.5, seconds);
clawMotor.setStopping(hold);
   clawMotor.setMaxTorque(30, percent);
   clawMotor.setTimeout(2, seconds);
   clawMotor.spinToPosition(180, degrees);
   wait(0.5, seconds);
 

Drivetrain.driveFor(forward, 300, mm);
wait(0.5, seconds);
Drivetrain.turnFor(left, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
Drivetrain.driveFor(forward, 600, mm);
wait(0.5, seconds);
Drivetrain.turnFor(right, 90, degrees, 15, velocityUnits::pct);
wait(0.5, seconds);
}
