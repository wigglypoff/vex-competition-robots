#pragma region VEXcode Generated Robot Configuration
// Make sure all required headers are included.
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>




#include "vex.h"


using namespace vex;


// Brain should be defined by default
brain Brain;




// START V5 MACROS
#define waitUntil(condition)                                                   \
 do {                                                                         \
   wait(5, msec);                                                             \
 } while (!(condition))


#define repeat(iterations)                                                     \
 for (int iterator = 0; iterator < iterations; iterator++)
// END V5 MACROS




// Robot configuration code.
motor RoboticArm1_mJ1 = motor(PORT1, ratio18_1, false);
motor RoboticArm1_mJ2 = motor(PORT2, ratio18_1, true);
motor RoboticArm1_mJ3 = motor(PORT3, ratio18_1, false);
motor RoboticArm1_mJ4 = motor(PORT4, ratio18_1, false);
pot RoboticArm1_mJ1_pot = pot(Brain.ThreeWirePort.A);
pot RoboticArm1_mJ2_pot = pot(Brain.ThreeWirePort.B);
pot RoboticArm1_mJ3_pot = pot(Brain.ThreeWirePort.C);
pot RoboticArm1_mJ4_pot = pot(Brain.ThreeWirePort.D);
RoboticArm RoboticArm1 = RoboticArm(RoboticArm1_mJ1, RoboticArm1_mJ1_pot, RoboticArm1_mJ2, RoboticArm1_mJ2_pot, RoboticArm1_mJ3, RoboticArm1_mJ3_pot, RoboticArm1_mJ4, RoboticArm1_mJ4_pot);


bumper EStop = bumper(Brain.ThreeWirePort.E);
#pragma endregion VEXcode Generated Robot Configuration
// Include the V5 Library
#include "vex.h"
 // Allows for easier use of the VEX Library
using namespace vex;


int Brain_precision = 0, Console_precision = 0;


float Index;


float Triangles[10][3];
float VEX[20][3];


event message1 = event();


// "when started" hat block
int whenStarted1() {
 RoboticArm1.setMasteringValues(1802.0,2212.0,1884.0,410.0);
 RoboticArm1.setToolTipOffset(1.05, 0.0, -1.0);
 RoboticArm1.moveToPositionLinear(3.039, -5.003, 3.0);
 wait(1.0, seconds);
 RoboticArm1.moveToPositionLinear(3.039, -5.504, 1.946);
 RoboticArm1.moveToPositionLinear(5.872, -5.751, 1.33);
 RoboticArm1.moveToPositionLinear(3.627, -3.627, 1.354);
 RoboticArm1.moveToPositionLinear(3.627, -3.627, 3.0);
 RoboticArm1.moveToPositionLinear(4.171, -2.598, 3.0);
 RoboticArm1.moveToPositionLinear(4.171, -2.598, 1.614);
 RoboticArm1.moveToPositionLinear(7.346, -3.313, 1.602);
 RoboticArm1.moveToPositionLinear(7.611, -2.613, 1.651);
 RoboticArm1.moveToPositionLinear(7.611, -2.613, 3.0);
 RoboticArm1.moveToPositionLinear(6.036, -2.084, 3.0);
 RoboticArm1.moveToPositionLinear(6.036, -2.084, 1.949);
 RoboticArm1.moveToPositionLinear(6.0, -3.5, 1.8);
 return 0;
}


// "when EStop pressed" hat block
void onevent_EStop_pressed_0() {
 RoboticArm1.emergencyStop();
}


// Used to find the format string for printing numbers with the
// desired number of decimal places
const char* printToBrain_numberFormat() {
 // look at the current precision setting to find the format string
 switch(Brain_precision){
   case 0:  return "%.0f"; // 0 decimal places (1)
   case 1:  return "%.1f"; // 1 decimal place  (0.1)
   case 2:  return "%.2f"; // 2 decimal places (0.01)
   case 3:  return "%.3f"; // 3 decimal places (0.001)
   default: return "%f"; // use the print system default for everthing else
 }
}


// "when started" hat block
int whenStarted2() {
 Brain.Screen.setFont(mono60);
 Brain_precision = 3;
 while (true) {
   Brain.Screen.clearScreen();
   // Display the X position on row 1
   Brain.Screen.setCursor(1, 1);
   Brain.Screen.print("X:");
   Brain.Screen.print(printToBrain_numberFormat(), static_cast<float>(RoboticArm1.getAxisPosition(xaxis)));
   Brain.Screen.newLine();
   // Display the Y position on row 2
   Brain.Screen.print("Y:");
   Brain.Screen.print(printToBrain_numberFormat(), static_cast<float>(RoboticArm1.getAxisPosition(yaxis)));
   Brain.Screen.newLine();
   // Display the Z position on row 3
   Brain.Screen.print("Z:");
   Brain.Screen.print(printToBrain_numberFormat(), static_cast<float>(RoboticArm1.getAxisPosition(zaxis)));
   wait(0.2, seconds);
 wait(5, msec);
 }
 return 0;
}




int main() {
 // register event handlers
 EStop.pressed(onevent_EStop_pressed_0);


 wait(15, msec);
 // post event registration


 // set default print color to black
 printf("\033[30m");


 // wait for rotation sensor to fully initialize
 wait(30, msec);


 vex::task ws1(whenStarted2);
 whenStarted1();
}

